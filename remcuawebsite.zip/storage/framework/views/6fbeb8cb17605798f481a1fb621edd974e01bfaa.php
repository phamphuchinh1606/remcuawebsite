<div class="block left-module product">
    <p class="title_block">Sản phẩm HOT</p>
    <div class="block_content">
        <!-- layered -->
        <div class="layered layered-category">
            <div class="layered-content">
                <div id="listPdHot">
                    <?php if(isset($productHots)): ?>
                        <?php $__currentLoopData = $productHots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="itemProduct">
                                <?php echo $__env->make('guest.common.__product_show_item',['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>