<?php use App\Common\AppCommon; ?>


<?php $__env->startSection('head.title','Danh sách đơn đặt hàng'); ?>

<?php $__env->startSection('head.css'); ?>
    <link href="<?php echo e(asset('css/admin/plugins/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/admin/plugins/daterangepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.breadcrumb'); ?>
    <?php echo e(Breadcrumbs::render('admin.order')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body.js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/admin/plugins/moment.min.js')); ?>" class="view-script"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/admin/plugins/jquery.dataTables.js')); ?>" class="view-script"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/admin/plugins/dataTables.bootstrap4.js')); ?>" class="view-script"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/admin/plugins/daterangepicker.min.js')); ?>" class="view-script"></script>
    <script>
        let startDate = "<?php echo e($searchForm['order_date']); ?>".split("-")[0];
        let endDate = "<?php echo e($searchForm['order_date']); ?>".split("-")[1];
        console.log(startDate);
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/admin/advanced-forms.js')); ?>" class="view-script"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    <div class="container-fluid">
        <div id="ui-view">
            <div>
                <div class="animated fadeIn">
                    <div class="card">
                        <div class="card-header">
                            <a data-toggle="collapse" data-parent="#searchForm" href="#searchForm" aria-expanded="true" aria-controls="searchForm" class="collapsed">
                                <i class="fa fa-edit"></i> Danh sách đơn đặt hàng
                            </a>
                        </div>
                        <div class="card-body">
                            <?php if(\Session::has('message')): ?>
                                <div class="alert alert-success"> <?php echo e(\Session::get('message')); ?></div>
                            <?php endif; ?>
                            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                <div class="row">
                                    <div class="collapse col-md-12" id="searchForm" role="tabpanel" style="">
                                        <?php echo $__env->make('admin.order.partials.__form_search_order',['searchForm' => $searchForm], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <table class="table table-striped table-bordered datatable dataTable no-footer" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info" style="border-collapse: collapse !important">
                                            <thead>
                                            <tr role="row">
                                                <th>
                                                    STT
                                                </th>
                                                <th>
                                                    Mã đơn hàng
                                                </th>
                                                <th>
                                                    Họ và tên
                                                </th>
                                                <th>
                                                    Số điện thoại
                                                </th>
                                                <th>
                                                    Email
                                                </th>
                                                <th>
                                                    Ngày đặt hàng
                                                </th>
                                                <th>
                                                    Tổng tiền
                                                </th>
                                                <th>
                                                    Tình trạng
                                                </th>
                                                <th>
                                                    Actions
                                                </th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($index + 1); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($order->order_code); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($order->full_name); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($order->phone_number); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($order->email); ?>

                                                    </td>
                                                    <td class="text-center">
                                                        <?php echo e(AppCommon::dateFormat($order->order_date)); ?>

                                                    </td>
                                                    <td class="text-right">
                                                        <?php echo e(AppCommon::formatMoney($order->total_amount)); ?>₫
                                                    </td>
                                                    <td class="text-center">
                                                        <span class="badge <?php echo e($order->status_class); ?>"><?php echo e($order->status_name); ?></span>
                                                    </td>
                                                    <td class="text-center">
                                                        <a class="btn btn-success" href="<?php echo e(route('admin.order.detail',['id' => $order->id])); ?>">
                                                            <i class="fa fa-search-plus"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <div class="pull-right">
                                            <?php echo e($orders->appends($searchForm)->links()); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>