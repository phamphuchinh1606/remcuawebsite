
<div class="block-menu-right">
    <ul class="list notStyle clearfix">
        <?php $__currentLoopData = $tagListTwo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('collection',['id' => $tag->product_type_id])); ?>"><?php echo e($tag->tag_name); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>