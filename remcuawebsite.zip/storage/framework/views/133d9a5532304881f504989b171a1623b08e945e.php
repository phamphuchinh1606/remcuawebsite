<footer id="stFooter">
    <div class="container">
        <div class="row">

            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 leftInfo">
                <div class="s-div-fot-ct">
                    <div class="s-fot-title">Thông tin liên hệ</div>
                    <div class="content">
                        <div class="ftLogo">
                            <div class="fi-title1 insScroll">
                                <a href="<?php echo e(route('home')); ?>" title="<?php echo e($appInfo->app_src_icon); ?>">
                                    <img class="insImageload"
                                        data-load="true"
                                        src="<?php echo e(asset($appInfo->app_src_icon)); ?>"
                                        alt="<?php echo e($appInfo->app_name); ?>"
                                        itemprop="logo">
                                </a>
                            </div>
                        </div>

                        <div class="ftShopInfo clearfix">
                            ĐC: <?php echo e($appInfo->app_address); ?> <br>
                            ĐT: <?php echo e($appInfo->app_phone); ?> <br>
                            Fax: <?php echo e($appInfo->app_fax); ?> <br>
                            Facebook: <?php echo e($appInfo->app_facebook); ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 rightMenu">
                <div class="row">

                    <div class="col-xs-12 col-sm-4 col-md-3 col-lg-4">
                        <div class="s-div-fot-ct">
                            <div class="s-fot-title">Về chúng tôi</div>
                            <ul class="s-mn-fot notStyle">


                                <li><a href="<?php echo e(route('home')); ?>">Trang chủ</a></li>


                                <li><a href="<?php echo e(route('collection_all')); ?>">Sản phẩm</a></li>


                                <li><a href="<?php echo e(route('blog')); ?>">Tin tức</a></li>


                                <li><a href="<?php echo e(route('about')); ?>">Giới thiệu</a></li>


                                <li><a href="<?php echo e(route('contact')); ?>">Liên hệ</a></li>


                            </ul>

                        </div>
                    </div>


                    <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <div class="s-div-fot-ct">
                            <div class="s-fot-title">Hỗ trợ</div>
                            <ul class="s-mn-fot notStyle">


                                <li><a href="<?php echo e(route('home')); ?>">Trang chủ</a></li>


                                <li><a href="<?php echo e(route('collection_all')); ?>">Sản phẩm</a></li>


                                <li><a href="<?php echo e(route('blog')); ?>">Tin tức</a></li>


                                <li><a href="<?php echo e(route('about')); ?>">Giới thiệu</a></li>


                                <li><a href="<?php echo e(route('contact')); ?>">Liên hệ</a></li>


                            </ul>

                        </div>
                    </div>


                    <div class="col-xs-12 col-sm-4 col-md-5 col-lg-4">
                        <div class="s-div-fot-ct">
                            <div class="s-fot-title">Kết nối với chúng tôi</div>
                            <div class="s-fot-lkw">
                                <a href="<?php echo e($appInfo->app_link_facebook_fanpage); ?>" target="_blank"><i class="fa fa-facebook"></i></a>
                                <a href="#2"><i class="fa fa-twitter"></i></a>
                                <a href="#3"><i class="fa fa-youtube"></i></a>
                                <a href="#4"><i class="fa fa-instagram"></i></a>
                                <a href="#5"><i class="fa fa-pinterest"></i></a>
                            </div>
                            
                            
                                  
                                
                                

                                
                                    
                                           
                                    
                                        
                                    
                                

                            
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="clear"></div>
    </div>

    <div class="overmenuhover"></div>
</footer>
