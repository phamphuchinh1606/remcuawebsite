<!doctype html>
<html lang="en">
<head>
    <head>
        <link rel="shortcut icon" href="<?php echo e(asset($appInfo->app_src_icon)); ?>" type="image/png"/>
        <meta charset="utf-8"/>
        <!--[if IE]>
        <meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'/>
        <![endif]-->
        <meta name="_token" content="<?php echo e(csrf_token()); ?>">
        <title>
            <?php echo $__env->yieldContent('head.title','Phu Chinh'); ?>
        </title>

        <meta content='width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=0' name='viewport'/>
        <meta name="description" content="<?php echo $__env->yieldContent('head.description',$appInfo->app_content); ?>">
        <meta name="keywords" content="<?php echo e($appInfo->app_content); ?>">
        <link rel="canonical" href="<?php echo e(URL::to('/')); ?>"/>
        <link rel="pingback" href="<?php echo e(URL::to('/')); ?>">
        <meta property="og:locale" content="vi_VN">
        <meta property="og:type" content="website">
        <meta property="og:title" content="<?php echo $__env->yieldContent('head.og.title',$appInfo->app_name); ?>">
        <meta property="og:description" content="<?php echo $__env->yieldContent('head.og.description',$appInfo->app_content); ?>">
        <meta property="og:url" content="<?php echo $__env->yieldContent('head.og.url',URL::to('/')); ?>">
        <meta property="og:site_name" content="<?php echo e($appInfo->app_name); ?>">
        <meta property="article:publisher" content="<?php echo e($appInfo->app_link_facebook_fanpage); ?>">
        <meta property="og:image" content="<?php echo $__env->yieldContent('head.og.image',asset('images/guest/icon_facebook.png')); ?>">
        <meta property="og:image:width" content="403">
        <meta property="og:image:height" content="540">

        <script type='text/javascript'>
            //<![CDATA[
            if ((typeof Haravan) === 'undefined') {
                Haravan = {};
            }
            Haravan.culture = 'vi-VN';
            Haravan.shop = 'remmangcuaphuonganh.com';
            Haravan.theme = {"name": "Rem mang cua", "id": 1000313408, "role": "main"};
            Haravan.domain = 'remmangcuaphuonganh.com';
            //]]>
        </script>
        <script type='text/javascript'>
            window.HaravanAnalytics = window.HaravanAnalytics || {};
            window.HaravanAnalytics.meta = window.HaravanAnalytics.meta || {};
            window.HaravanAnalytics.meta.currency = 'VND';
            var meta = {"page": {"pageType": "home"}};
            for (var attr in meta) {
                window.HaravanAnalytics.meta[attr] = meta[attr];
            }
        </script>
        <script async src='<?php echo e(asset('/js/guest/plugins/haravan-analytics.min.js?v=3')); ?>' type='text/javascript'></script>

        <script src='<?php echo e(asset('/js/guest/plugins/jquery.min.js?v=1543')); ?>' type='text/javascript'></script>
        <!--------------CSS----------->

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


        <link href='<?php echo e(asset('/css/guest/plugins/plugins.css?v=1543')); ?>' rel='stylesheet' type='text/css' media='all'/>
        <link href='<?php echo e(asset('/css/guest/plugins/styles.css?v=1543')); ?>' rel='stylesheet' type='text/css' media='all'/>
        <link href='<?php echo e(asset('/css/guest/style.css?v=1543')); ?>' rel='stylesheet' type='text/css' media='all'/>
        <script src='<?php echo e(asset('/js/guest/plugins/countdown.js?v=1543')); ?>' type='text/javascript'></script>
        <link href='<?php echo e(asset('/css/guest/plugins/call.css')); ?>' rel='stylesheet' type='text/css' media='all'/>

        <script>
            <?php $amount = '100,000'; ?>
                $1 = "";
            window.shop = {
                template: "<?php echo $__env->yieldContent('template','index'); ?>",
                moneyFormat: "<?php echo e($amount); ?>₫"
            }
        </script>
        <?php echo $__env->yieldContent('head.init_js'); ?>
        <script src="<?php echo e(asset('/js/guest/plugins/platform.js')); ?>" async defer>
            {
                lang: 'vi'
            }
        </script>
        <script type="text/javascript">
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });
        </script>

        
        <?php echo $__env->yieldContent('head.css'); ?>
        <style>
            body{
                /*background-color: #00aced;*/
                background-image: url('<?php echo e(asset('images/guest/bg_2.png')); ?>');
                background-repeat-x: repeat-y;
                background-repeat-y: repeat-y;
            }
        </style>
    </head>
</head>
<body class="stTheme <?php echo $__env->yieldContent('class_body'); ?>">
    <div class="page_layout">
        <section class="stBody">
            
            
                
                    
                
            

            <header id="insHeaderPage" class="headerTemp">
                
                <?php echo $__env->make('guest.layouts.partials.__top_menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                
                <?php echo $__env->make('guest.layouts.partials.__header_page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                
                <?php echo $__env->make('.guest.layouts.partials.__header_menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </header>
            <div class="stMain">
                <?php echo $__env->yieldContent('body.content'); ?>
            </div>
            
            <?php echo $__env->make('guest.layouts.partials.__footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </section>
    </div>

    
    <?php echo $__env->make('guest.layouts.partials.__modal_quick_view', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <script src="<?php echo e(asset('/js/guest/plugins/plugins.js?v=1543')); ?>" type='text/javascript'></script>

    <script src="<?php echo e(asset('/js/guest/plugins/builder.js?v=1543')); ?>" type='text/javascript'></script>

    <script src="<?php echo e(asset('/js/guest/plugins/tmp_jsquoc.js?v=1543')); ?>" type='text/javascript'></script>

    <script src="<?php echo e(asset('/js/guest/plugins/snow.js?v=1543')); ?>" type='text/javascript'></script>



    <?php echo $__env->yieldContent('body.js'); ?>

    <?php echo $__env->make('guest.layouts.partials.__call_phone_plugin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

</body>

<?php echo $__env->make('guest.layouts.partials.__chat_box_facebook_plugin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</html>
