<?php $__env->startSection('body.breadcrumb'); ?>
    <?php echo e(Breadcrumbs::render('admin.home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    <div class="container-fluid">
        <div id="ui-view">
            <div class="row">
                <table class="table table-responsive-sm table-hover table-outline mb-0">
                    <thead class="thead-light">
                    <tr>
                        <th class="text-center">
                            STT
                        </th>
                        <th>Hò và tên</th>
                        <th>Số điện thoại</th>
                        <th>Email</th>
                        <th>Ngày liên hệ</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $contactsNew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center">
                                    <?php echo e($index+1); ?>

                                </td>
                                <td>
                                    <?php echo e($contact->guest_name); ?>

                                </td>
                                <td>
                                    <?php echo e($contact->guest_phone); ?>

                                </td>
                                <td>
                                    <?php echo e($contact->guest_email); ?>

                                </td>
                                <td>
                                    <?php echo e($contact->created_at); ?>

                                </td>
                                <td class="text-center">
                                    <a class="btn btn-success" href="<?php echo e(route('admin.contact.show',['id' => $contact->id])); ?>">
                                        <i class="fa fa-search-plus"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>