<?php if(count($breadcrumbs)): ?>
    <?php if(Auth::check() && Request::is('*admin*') ): ?>
        <ol class="breadcrumb">
            <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($breadcrumb->url && !$loop->last): ?>
                    <li class="breadcrumb-item">
                        <a href="<?php echo e($breadcrumb->url); ?>"><?php echo e($breadcrumb->title); ?></a>
                    </li>
                <?php else: ?>
                    <li class="breadcrumb-item active"><?php echo e($breadcrumb->title); ?></li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    <?php else: ?>
        <div class="insBreadcrumb ">
            <div class="container">
                <div class="breadcrumb-wrap">
                    <ol class="breadcrumb breadcrumb-arrow hidden-sm hidden-xs">
                        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($breadcrumb->url && !$loop->last): ?>
                                <li>
                                    <a href="<?php echo e($breadcrumb->url); ?>" target="_self"><?php echo e($breadcrumb->title); ?></a>
                                </li>
                            <?php else: ?>
                                <li class="active"><span><?php echo e($breadcrumb->title); ?></span></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>
