<?php use App\Common\Constant; ?>



<?php $__env->startSection('head.title','Thông tin giới thiệu'); ?>

<?php $__env->startSection('head.css'); ?>
    <link href="<?php echo e(asset('css/admin/plugins/quill.snow.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.js'); ?>
    <script src="<?php echo e(asset('js/admin/plugins/quill.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/plugins/text-editor.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    <div class="container-fluid">
        <div id="ui-view">
            <div class="row">
                <div class="col-md-12">
                    <form action="<?php echo e(route('admin.setting.app_about')); ?>" method="post" enctype="multipart/form-data"
                          id="form">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($appInfo->id); ?>" name="app_id"/>
                        <div class="card list-image">
                            <div class="card-header">
                                <i class="fa fa-align-justify"></i>Thông tin giới thiệu trang
                            </div>
                            <div class="card-body">
                                <input type="hidden" value="<?php echo e($appInfo->about_content); ?>" class="editor" name="about_content"/>
                                <div id="editor" class="ql-container ql-snow editor_quill product_content" style="min-height: 700px">
                                    <?php echo $appInfo->about_content; ?>

                                </div>
                            </div>
                            <div class="card-footer">
                                <button class="btn btn-sm btn-primary pull-right" type="submit">
                                    <i class="fa fa-dot-circle-o"></i> Cập Nhật
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>