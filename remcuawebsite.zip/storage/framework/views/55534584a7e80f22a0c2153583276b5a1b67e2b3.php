<?php $__env->startSection('head.title','Danh sách thông tin liên hệ'); ?>

<?php $__env->startSection('head.css'); ?>
    <link href="<?php echo e(asset('css/admin/plugins/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/admin/plugins/jquery.dataTables.js')); ?>" class="view-script"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/admin/plugins/dataTables.bootstrap4.js')); ?>" class="view-script"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.breadcrumb'); ?>
    <?php echo e(Breadcrumbs::render('admin.contact')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    <div class="container-fluid">
        <div id="ui-view">
            <div>
                <div class="animated fadeIn">
                    <div class="card">
                        <div class="card-header">
                            <i class="fa fa-edit"></i> Danh sách thông tin liên hệ
                        </div>
                        <div class="card-body">
                            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <table class="table table-striped table-bordered datatable dataTable no-footer" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info" style="border-collapse: collapse !important">
                                            <thead>
                                            <tr role="row">
                                                <th>
                                                    STT
                                                </th>
                                                <th>
                                                    Họ và tên
                                                </th>
                                                <th>
                                                    Số điện thoại
                                                </th>
                                                <th>
                                                    Email
                                                </th>
                                                <th>
                                                    Ngày liên hệ
                                                </th>
                                                <th>
                                                    Tình trạng
                                                </th>
                                                <th>
                                                    Actions
                                                </th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($index + 1); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($contact->guest_name); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($contact->guest_phone); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($contact->guest_email); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($contact->created_at); ?>

                                                    </td>
                                                    <td class="text-center">
                                                        <span class="badge <?php echo e($contact->status_class); ?>"><?php echo e($contact->status_name); ?></span>
                                                    </td>
                                                    <td class="text-center">
                                                        <a class="btn btn-success" href="<?php echo e(route('admin.contact.show',['id' => $contact->id])); ?>">
                                                            <i class="fa fa-search-plus"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>