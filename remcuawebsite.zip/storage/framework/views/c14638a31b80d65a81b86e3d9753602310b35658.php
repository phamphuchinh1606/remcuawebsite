<section class="control-block pdHomeBlock">
    <div class="container">
        <div class="row">
            <!-- BlockProduct1 _ Slide Banner & Product -->
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 homeBlockLeft">
                <div class="wrapperBlockProduct">
                    <div class="heading-product">
						<span class="holder_header">
							<span class="line_title orange"></span>
						</span>
                        <h4><?php echo e($blockHeader); ?></h4>
                        <span class="holder_header">
							<span class="line_title orange"></span>
						</span>
                    </div>
                    <div class="woocommerce product-list">
                        <div class="row">
                            <?php if(isset($products)): ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make('guest.common.__product_show_item_detail',['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- BlockPromotion1 & Banner Ads -->
            

                


                    
                        
                            
                                

                                
                                    
                                


                                
                                   
                                    
                                         
                                         

                                
                                
                                    
                                        
                                           
                                                    
                                        
                                           
                                           
                                                    
                                    
                                
                            
                            
                                
                                                          
                                                          
                                

                                    
                                    

                                
                            
                        
                        
                            
                                
                                    
                                    
                                    
                                
                            
                        
                    
                


                
                    
                        
                             
                    
                

            
        </div>
    </div>
</section>
