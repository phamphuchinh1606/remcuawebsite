<?php $__env->startSection('head.title','Danh Sách Sản Phẩm'); ?>

<?php $__env->startSection('head.css'); ?>
    <link href="<?php echo e(asset('css/admin/product.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.breadcrumb'); ?>
    <?php echo e(Breadcrumbs::render('admin.product')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    <div class="container-fluid">
        <div id="ui-view">
            <div>
                <div class="animated fadeIn">
                    <div class="card">
                        <div class="card-header">
                            <i class="fa fa-edit"></i> Danh Sách Sản Phẩm
                            <div class="card-header-actions">
                                <a class="btn btn-block btn-outline-primary active" href="<?php echo e(route('admin.product.create')); ?>">
                                    Tạo mới
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <table class="table table-striped table-bordered datatable dataTable no-footer" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info" style="border-collapse: collapse !important">
                                            <thead>
                                            <tr role="row">
                                                <th class="sorting_asc app-col-stt">
                                                    STT
                                                </th>
                                                <th class="sorting app-col-img">
                                                    Hình Ảnh
                                                </th>
                                                <th class="sorting app-col-name" >
                                                    Tên Sản Phẩm
                                                </th>
                                                <th class="sorting app-col-code" >
                                                    Mã Sản Phẩm
                                                </th>
                                                <th class="sorting app-col-type" >
                                                    Loại Sản Phẩm
                                                </th>
                                                <th class="sorting app-col-price" >
                                                    Giá Bán
                                                </th>
                                                <th class="sorting app-col-status" >
                                                    Tình Trạng
                                                </th>
                                                <th class="sorting app-col-action">
                                                    Actions
                                                </th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr role="row" class="odd">
                                                    <td class="text-right">
                                                        <?php echo e($key + 1); ?>

                                                    </td>
                                                    <td >
                                                        <img src="<?php echo e(asset(\App\Common\Constant::$PATH_URL_UPLOAD_IMAGE.$product->product_image)); ?>" width="100" height="100"/>
                                                    </td>
                                                    <td class="">
                                                        <?php echo e($product->product_name); ?>

                                                    </td>
                                                    <td class="">
                                                        <?php echo e($product->product_code); ?>

                                                    </td>
                                                    <td class="">
                                                        <?php echo e($product->product_type_name); ?>

                                                    </td>
                                                    <td class="text-right">
                                                        <?php echo e($product->product_price); ?>

                                                    </td>
                                                    <td class="">
                                                        <span class="badge <?php echo e($product->public_class); ?>"><?php echo e($product->public_name); ?></span>
                                                    </td>
                                                    <td class="text-center">
                                                        
                                                            
                                                        
                                                        <a class="btn btn-info" href="<?php echo e(route('admin.product.update',['id' => $product->id])); ?>">
                                                            <i class="fa fa-edit"></i>
                                                        </a>
                                                        <a data-toggle="modal" class="btn btn-danger anchorClick"
                                                           data-url="<?php echo e(route('admin.product.delete',['id' => $product->id])); ?>"
                                                           data-name="<?php echo e($product->product_name); ?>" href="#deleteModal">
                                                            <i class="fa fa-trash-o"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <div class="pull-right">
                                            <?php echo e($products->links()); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>