<?php use App\Common\Constant; ?>
<div class="main-sidebar">
    <div class="title-sidebar">
        <a href="">
            <div class="icon"><span></span></div>
            <h2>
                Danh mục sản phẩm
            </h2>
        </a>
    </div>
    <ul class="list-group">
        <?php $__currentLoopData = $productTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $isChilds =  isset($productType->childs) && count($productType->childs) > 0 ; ?>
            <li class="root_parent actived <?php if($isChilds): ?> nomega has_megamenu <?php endif; ?> ">
                <a href="<?php echo e(route('collection',['slug' => isset($productType->slug) ? $productType->slug : '1', 'id' => $productType->id])); ?>">
                    <?php if(isset($productType->image_icon)): ?>
                        <img src="<?php echo e(\App\Common\Constant::$PATH_URL_UPLOAD_IMAGE.$productType->image_icon); ?>"/>
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/guest/icon-menu.png')); ?>"/>
                    <?php endif; ?>

                    <?php echo e($productType->product_type_name); ?>

                    <?php if($isChilds): ?>
                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                    <?php endif; ?>
                </a>

                <?php if($isChilds): ?>
                    <ul class="mainChild levlup_2" role="menu">
                        <?php $__currentLoopData = $productType->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="dropdownmenu2">
                                <a href="<?php echo e(route('collection',['slug' => isset($child->slug) ? $child->slug : '1', 'id' => $child->id])); ?>" title="<?php echo e($child->product_type_name); ?>">
                                    <span><?php echo e($child->product_type_name); ?></span>
                                    
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
                
                        
                

            
                
                

                    
                        

                        

                            

                            

                            

                            

                            

                        

                    

                    
                        

                        

                            

                            

                            

                            

                            

                        

                    

                    
                        

                        

                            

                            

                            

                            

                            

                        

                    

                    
                        

                        

                            

                            

                            

                            

                            

                        

                    

                    
                        

                        

                            

                            

                            

                            

                            

                        

                    

                    
                
            

        


        
                        
                


        
                        
                


        
                        
                

            
                
                

                    
                        

                        

                            

                            

                            

                            

                            

                        

                    

                    
                        

                        

                            

                            

                            

                            

                            

                        

                    

                    
                        

                        

                            

                            

                            

                            

                            

                        

                    

                    
                        

                        

                            

                            

                            

                            

                            

                        

                    

                    
                        

                        

                            

                            

                            

                            

                            

                        

                    

                    
                
            

        


        
                        
                

            

                
                    
                                

                    

                        
                            
                               
                        

                        
                            
                        

                        
                            
                        

                        
                            
                        

                    

                

                
                    
                                

                    

                        
                            
                        

                        
                            
                        

                        
                            
                        

                    

                

                
                    

                

                
                    

                

            

        


        
                        
                


        
                        
                


        
                        
                


        
                        
                


        
                        
                


    </ul>
</div>
