<div class="section-content">
    <div class="fieldset">
            <input name="selected_customer_shipping_province" type="hidden" value="">
            <input name="selected_customer_shipping_district" type="hidden" value="">
            <input name="selected_customer_shipping_ward" type="hidden" value="">
            <input name="utf8" type="hidden" value="✓">

            <div class="field field-show-floating-label  field-half ">
                <div class="field-input-wrapper field-input-wrapper-select">
                    <label class="field-label" for="customer_shipping_province"> Tỉnh / thành  </label>
                    <select class="field-input" name="province">
                        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($province->code); ?>" ><?php echo e($province->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                        



                    </select>
                </div>

            </div>


            <div class="field field-show-floating-label  field-half ">
                <div class="field-input-wrapper field-input-wrapper-select">
                    <label class="field-label" for="customer_shipping_district">Quận / huyện</label>
                    <select class="field-input" name="district">
                        <option data-code="null" value="null" selected="">Chọn quận / huyện</option>

                        <option data-code="HC466" value="466">Quận 1</option>

                        <option data-code="HC467" value="467">Quận 2</option>

                        <option data-code="HC468" value="468">Quận 3</option>

                        <option data-code="HC469" value="469">Quận 4</option>

                        <option data-code="HC470" value="470">Quận 5</option>

                        <option data-code="HC471" value="471">Quận 6</option>

                        <option data-code="HC472" value="472">Quận 7</option>

                        <option data-code="HC473" value="473">Quận 8</option>

                        <option data-code="HC474" value="474">Quận 9</option>

                        <option data-code="HC475" value="475">Quận 10</option>

                        <option data-code="HC476" value="476">Quận 11</option>

                        <option data-code="HC477" value="477">Quận 12</option>

                        <option data-code="HC478" value="478">Quận Gò Vấp</option>

                        <option data-code="HC479" value="479">Quận Tân Bình</option>

                        <option data-code="HC480" value="480">Quận Bình Thạnh</option>

                        <option data-code="HC481" value="481">Quận Phú Nhuận</option>

                        <option data-code="HC482" value="482">Quận Thủ Đức</option>

                        <option data-code="HC483" value="483">Huyện Củ Chi</option>

                        <option data-code="HC484" value="484">Huyện Hóc Môn</option>

                        <option data-code="HC485" value="485">Huyện Bình Chánh</option>

                        <option data-code="HC486" value="486">Huyện Nhà Bè</option>

                        <option data-code="HC487" value="487">Huyện Cần Giờ</option>

                        <option data-code="HC679" value="679">Quận Bình Tân</option>

                        <option data-code="HC680" value="680">Quận Tân Phú</option>

                    </select>
                </div>

            </div>
    </div>
</div>

<script type="text/ecmascript">
    $(document).ready(function(){
        $('select[name=province]').val(<?php echo e($shippingInfo['province']); ?>);
        $('select[name=district]').val(<?php echo e($shippingInfo['district']); ?>);
        $('select[name=province]').on('change',function(){
            let value = $(this).val();
            let params = {
                type: 'GET',
                url: '/cart/district',
                data: 'province_code='+ value,
                dataType: 'json',
                success: function(data) {
                    let selectDistrict = $('select[name=district]');
                    selectDistrict.html('');
                    data.forEach(function(district){
                        selectDistrict.append(
                            "<option value='"+district.code+"'>"+district.label+"</option>"
                        );
                    });
                }
            };
            jQuery.ajax(params);
        });
    });
</script>
