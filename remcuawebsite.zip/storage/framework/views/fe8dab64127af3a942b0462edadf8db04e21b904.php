<script>
    let searchInfo = {
        'product_type' : '<?php echo e($searchInfo->product_type); ?>',
        'product_price' : '<?php echo e($searchInfo->product_price); ?>'
    };
    function getSearchInfo(){
        searchInfo.product_type = '';
        $('input[name=product_type]').each(function(){
            if($(this).prop("checked")){
                searchInfo.product_type += (searchInfo.product_type == '' ? '' : '-') + $(this).val();
            }
        });
        searchInfo.product_price = '';
        $('input[name=search_price]').each(function(){
            if($(this).prop("checked")){
                searchInfo.product_price += (searchInfo.product_price == '' ? '' : '-') + $(this).val();
            }
        });
    }
    $(document).ready(function(){
       if(searchInfo.product_type != null && searchInfo.product_type != undefined){
           let listProductTypeId = searchInfo.product_type.split('-');
           for(productTypeId of listProductTypeId)
           {
               $('#product_type_'+ productTypeId).prop( "checked", true );
           }
       }
        if(searchInfo.product_price != null && searchInfo.product_price != undefined){
            let listPrice = searchInfo.product_price.split('-');
            for(price of listPrice)
            {
                $('#product_price_'+ price).prop( "checked", true );
            }
        }

       $('.search_info').on('click',function(){
           getSearchInfo();
           $('#btn-apply').removeClass('hide');
       });
        $('#btn-apply').on('click',function(){
            window.location = "<?php echo e(route('collection_all')); ?>" + "?product_type="+searchInfo.product_type+"&product_price="+searchInfo.product_price;
        });
    });


</script>

<div class="block left-module">
    <p class="title_block">
        Bộ lọc
        <button type="button" class="btn btn-primary pull-right hide" id="btn-apply">Áp dụng</button>
    </p>

    <div class="block_content filter_xs">
        <!-- layered -->
        <div class="layered layered-filter-price">
            <!-- ./filter brand -->

            <div class="layered_subtitle">Loại Sản Phẩm</div>
            <div class="layered-content filter-brand">
                <ul class="check-box-list">
                    <?php $__currentLoopData = $productTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <input class="search_info" type="checkbox" id="product_type_<?php echo e($productType->id); ?>" name="product_type" value="<?php echo e($productType->id); ?>">
                            <label for="product_type_<?php echo e($productType->id); ?>">
                                <span class="button"></span>
                                <?php echo e($productType->product_type_name); ?>

                            </label>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            
            
                

                    
                        
                        
                            
                            
                        
                    

                    
                        
                        
                            
                            
                        
                    

                    
                        
                        
                            
                            
                        
                    

                    
                        
                        
                            
                            
                        
                    

                    
                        
                        
                            
                            
                        
                    

                    
                        
                        
                            
                            
                        
                    

                    
                        
                        
                            
                            
                        
                    

                
            

            <!-- ./filter brand -->
            <!-- filter price -->

            <div class="layered_subtitle">Giá</div>
            <div class="layered-content slider-range filter-price">
                <ul class="check-box-list">
                    <li>
                        <input type="checkbox" id="product_price_less_100000" class="search_info" name="search_price" value="less_100000">
                        <label for="product_price_less_100000">
                            <span class="button"></span>
                            Dưới 100,000₫
                        </label>
                    </li>
                    <li>
                        <input type="checkbox" id="product_price_100000_300000" class="search_info" name="search_price" value="100000_300000">
                        <label for="product_price_100000_300000">
                            <span class="button"></span>
                            100,000₫ - 300,000₫
                        </label>
                    </li>
                    <li>
                        <input type="checkbox" id="product_price_300000_500000" class="search_info" name="search_price" value="300000_500000">
                        <label for="product_price_300000_500000">
                            <span class="button"></span>
                            300,000₫ - 500,000₫
                        </label>
                    </li>
                    <li>
                        <input type="checkbox" id="product_price_500000_1000000" class="search_info" name="search_price" value="500000_1000000">
                        <label for="product_price_500000_1000000">
                            <span class="button"></span>
                            500,000₫ - 1,000,000₫
                        </label>
                    </li>
                    <li>
                        <input type="checkbox" id="product_price_bigger_1000000" class="search_info" name="search_price" value="bigger_1000000">
                        <label for="product_price_bigger_1000000">
                            <span class="button"></span>
                            Trên 1,000,000₫
                        </label>
                    </li>
                </ul>
            </div>
            <!-- ./filter price -->
            <!-- filter color -->

            
            
                
                    
                        
                        
                    
                    
                        
                        
                    
                    
                        
                        
                    
                    
                        
                        
                    
                    
                        
                        
                    
                    
                        
                        
                    
                    
                        
                        
                    
                    
                        
                        
                    
                    
                        
                        
                    
                    
                        
                        
                    


                
            

            <!-- ./filter color -->
            <!-- ./filter size -->

            
            

                

                    
                        
                        
                            
                        
                    

                    
                        
                        
                            
                        
                    

                    
                        
                        
                            
                        
                    

                    
                        
                        
                            
                        
                    

                    
                        
                        
                            
                        
                    

                    
                        
                        
                            
                        
                    

                    
                        
                        
                            
                        
                    

                    
                        
                        
                            
                        
                    

                
            

            <!-- ./filter size -->
        </div>
        <!-- ./layered -->

    </div>
</div>
