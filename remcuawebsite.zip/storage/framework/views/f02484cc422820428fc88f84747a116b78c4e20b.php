<?php use App\Common\Constant; ?>
<?php use App\Common\AppCommon; ?>


<?php $__env->startSection('head.title','Chi tiết đơn hàng'); ?>

<?php $__env->startSection('head.css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.breadcrumb'); ?>
    <?php echo e(Breadcrumbs::render('admin.order.show')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body.content'); ?>
    <div class="container-fluid">
        <div id="ui-view">
            <div>
                <div class="animated fadeIn">
                    <div class="row">
                        <div class="col-md-12">
                            <form method="post" action="">
                                <?php echo csrf_field(); ?>
                                <div class="card">
                                    <div class="card-header">
                                        <i class="icon-note"></i> Chi tiết đơn hàng
                                        <div class="card-header-actions">
                                            <a class="btn btn-sm btn-secondary" href="<?php echo e(route('admin.order.index')); ?>">
                                                Quay Lại
                                            </a>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-md-2 col-form-label" for="text-input">Mã đơn hàng</label>
                                                    <div class="col-md-10">
                                                        <p class="form-control-static col-form-label font-weight-bold"><?php echo e($order->id); ?></p>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-md-2 col-form-label">Tên khách hàng</label>
                                                    <div class="col-md-10">
                                                        <p class="form-control-static col-form-label font-weight-bold"><?php echo e($order->full_name); ?></p>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-md-2 col-form-label">Số điện thoại</label>
                                                    <div class="col-md-10">
                                                        <p class="form-control-static col-form-label font-weight-bold"><?php echo e($order->phone_number); ?></p>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-md-2 col-form-label">Địa chỉ</label>
                                                    <div class="col-md-10">
                                                        <p class="form-control-static col-form-label font-weight-bold"><?php echo e($order->address); ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-md-2 col-form-label">Email</label>
                                                    <div class="col-md-10">
                                                        <p class="form-control-static col-form-label font-weight-bold"><?php echo e($order->email); ?></p>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-md-2 col-form-label">Ngày đặt hàng</label>
                                                    <div class="col-md-10">
                                                        <p class="form-control-static col-form-label font-weight-bold"><?php echo e(AppCommon::dateFormat($order->order_date)); ?></p>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-md-2 col-form-label">Trạng thái</label>
                                                    <div class="col-md-10">
                                                        <p class="form-control-static col-form-label font-weight-bold badge <?php echo e($order->status_class); ?>"><?php echo e($order->status_name); ?></p>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-md-2 col-form-label">Tổng tiền</label>
                                                    <div class="col-md-10">
                                                        <p class="form-control-static col-form-label font-weight-bold text-danger"><?php echo e(AppCommon::formatMoney($order->total_amount)); ?> ₫</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <i class="icon-note"></i> Danh sách sản phẩm
                                                    </div>
                                                    <div class="card-body">
                                                        <table class="table table-striped table-bordered datatable dataTable no-footer" id="DataTables_Table_0" role="grid"
                                                               aria-describedby="DataTables_Table_0_info" style="border-collapse: collapse !important">
                                                            <thead>
                                                            <tr role="row">
                                                                <th>
                                                                    STT
                                                                </th>
                                                                <th>
                                                                    Mã sản phẩm
                                                                </th>
                                                                <th>
                                                                    Tên sản phẩm
                                                                </th>
                                                                <th>
                                                                    Đơn giá
                                                                </th>
                                                                <th>
                                                                    Số lượng
                                                                </th>
                                                                <th>
                                                                    Thành tiền
                                                                </th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td>
                                                                        <?php echo e($index + 1); ?>

                                                                    </td>
                                                                    <td>
                                                                        <?php echo e($orderDetail->product_id); ?>

                                                                    </td>
                                                                    <td>
                                                                        <a href="<?php echo e(route('admin.product.update',['id' => $orderDetail->product_id])); ?>" target="_blank">
                                                                            <?php echo e($orderDetail->product_name); ?>

                                                                        </a>
                                                                    </td>
                                                                    <td class="text-right">
                                                                        <?php echo e(AppCommon::formatMoney($orderDetail->product_price)); ?>₫
                                                                    </td>
                                                                    <td class="text-right">
                                                                        <?php echo e($orderDetail->product_qty); ?>

                                                                    </td>
                                                                    <td class="text-right">
                                                                        <?php echo e(AppCommon::formatMoney($orderDetail->total_money)); ?>₫
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer text-center">
                                        <?php if($isShowConfirm): ?>
                                            <a data-toggle="modal" class="btn btn-sm btn-primary p-2 primaryPopupClick"
                                               data-url="<?php echo e(route('admin.order.detail.confirm',['id' => $order->id])); ?>"
                                               data-title="Xác nhận đơn hàng"
                                               data-content="Bạn có thực sự muốn xác nhận đơn hàng cho <b><?php echo e($order->full_name); ?></b>"
                                               data-name="<?php echo e($order->full_name); ?>" data-target="#primaryModal" href="#primaryModal"
                                               data-name-cancel="Không" data-name-ok="Xác nhận">
                                                Xác nhận đơn hàng
                                            </a>
                                        <?php endif; ?>

                                        <?php if($isShowShipping): ?>
                                            <a data-toggle="modal" class="btn btn-sm btn-warning p-2 warningPopupClick"
                                               data-url="<?php echo e(route('admin.order.detail.shipping',['id' => $order->id])); ?>"
                                               data-title="Vận chuyển đơn hàng"
                                               data-content="Bạn có thực sự muốn chuyển hàng cho <b><?php echo e($order->full_name); ?></b>"
                                               data-name="<?php echo e($order->full_name); ?>" data-target="#warningModal" href="#warningModal"
                                               data-name-cancel="Không" data-name-ok="Chuyển hàng">
                                                Đang giao hàng
                                            </a>
                                        <?php endif; ?>

                                        <?php if($isShowFinish): ?>
                                            <a data-toggle="modal" class="btn btn-sm btn-success p-2 successPopupClick"
                                               data-url="<?php echo e(route('admin.order.detail.finish',['id' => $order->id])); ?>"
                                               data-title="Hoàn thành kết thúc đơn hàng"
                                               data-content="Bạn có thực sự muốn hoàn thành đơn hàng cho <b><?php echo e($order->full_name); ?></b>"
                                               data-name="<?php echo e($order->full_name); ?>" data-target="#successModal" href="#successModal"
                                               data-name-cancel="Không" data-name-ok="Hoàn thành">
                                                Hoàn thành đơn hàng
                                            </a>
                                        <?php endif; ?>

                                        <?php if($isShowCancel): ?>
                                            <a data-toggle="modal" class="btn btn-sm btn-danger p-2 dangerPopupClick"
                                               data-url="<?php echo e(route('admin.order.detail.cancel',['id' => $order->id])); ?>"
                                               data-title="Xác nhận hủy đơn hàng"
                                               data-content="Bạn có thực sự muốn hủy đơn hàng của <b><?php echo e($order->full_name); ?></b>"
                                               data-name="<?php echo e($order->full_name); ?>" data-target="#dangerModal" href="#dangerModal"
                                               data-name-cancel="Không" data-name-ok="Hủy đơn hàng">
                                                <i class="fa fa-ban"></i> Hủy đơn hàng</button>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.popup'); ?>
    <?php echo $__env->make('admin.common.__popup_primary_modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.common.__popup_warning_modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.common.__popup_success_modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.common.__popup_danger_modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>