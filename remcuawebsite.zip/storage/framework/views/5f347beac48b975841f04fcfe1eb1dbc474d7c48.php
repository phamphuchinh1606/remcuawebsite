<?php $__env->startSection('head.title','Tìm kiếm sản phẩm'); ?>

<?php $__env->startSection('head.css'); ?>
    <link href='<?php echo e(asset('/css/guest/plugins/pages.css?v=1543')); ?>' rel='stylesheet' type='text/css'  media='all'  />
    <style>
        .product-list.products .itemProduct {
            margin-top: 0px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('template','collection'); ?>

<?php $__env->startSection('body.content'); ?>
    <section id="stSearchPage">
        <?php echo e(Breadcrumbs::render('guest.search', 'Tìm kiếm: Kết quả tìm kiếm với ( '.$product_name.' )')); ?>


        <div class="container">
            <div class="searchResults">
                <div class="searchHead">
                    <p>
                        Tìm thấy <span> <?php echo e(count($products)); ?> kết quả với từ khóa <i>"<?php echo e($product_name); ?>"</i>...</span>
                    </p>
                </div>
                <ul class="product-list filter products clearfix notStyle pdListItem view_grid">
                    <?php if(isset($products) && count($products) > 0): ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="itemProduct col-md-3 col-sm-6 col-xs-6">
                                <?php echo $__env->make('guest.common.__product_show_item',['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
                <div class="clearfix"></div>
                <div class="col-md-12 content_sortPagiBar pagi">
                    <div id="pagination" class="clearfix">
                        <?php echo e($products->appends(['product_name'=>$product_name])->links('both.common.view_pagging')); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>