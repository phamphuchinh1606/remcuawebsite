<?php $__env->startSection('head.title'); ?>
    <?php echo e($appInfo->app_name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head.css'); ?>
    <link href='<?php echo e(asset('/css/guest/plugins/home.css?v=1543')); ?>' rel='stylesheet' type='text/css' media='all'/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('class_body','stHome'); ?>

<?php $__env->startSection('body.content'); ?>
    
    <section class="slider-sidebar">
        <div class="container">
            <div class="row">
                <div id="menuSidebar" class="col-md-3 visible-lg visible-md">
                    <?php echo $__env->make('guest.home.partials.__menu_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div id="mainSlider" class="col-md-9 ">
                    <?php echo $__env->make('guest.home.partials.__slider_sidebar',['banners' => $banners], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </section>

        
        <?php echo $__env->make('guest.home.partials.__banner_top',['topBanners' => $topBanners], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('guest.home.partials.__product_home_block',['blockHeader' => 'Sản Phẩm Mới','products' => $productNews], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('guest.home.partials.__product_home_block',['blockHeader' => 'Sản Phẩm Bán Chạy','products' => $productHots], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        
        
        
        
        
        
        
        
        

        
        <?php echo $__env->make('guest.home.partials.__make_product_video', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('guest.home.partials.__process_delivery', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <div class="clear"></div>

    
    <?php echo $__env->make('guest.home.partials.__blog_new', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>