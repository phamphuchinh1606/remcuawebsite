<?php use App\Common\Constant; use App\Common\AppCommon; ?>



<?php $__env->startSection('head.title', $product->product_name); ?>

<?php $__env->startSection('head.description', $product->product_description); ?>

<?php $__env->startSection('head.og.title',$product->product_name); ?>
<?php $__env->startSection('head.og.description',$product->product_description); ?>
<?php $__env->startSection('head.og.image',asset(Constant::$PATH_URL_UPLOAD_IMAGE.$product->product_image)); ?>
<?php $__env->startSection('head.og.url',route('product_detail',['id' => $product->id, 'slug' => $product->slug])); ?>

<?php $__env->startSection('head.css'); ?>
    <link href='<?php echo e(asset('/css/guest/plugins/pages.css?v=1543')); ?>' rel='stylesheet' type='text/css'  media='all'  />
    <link href='<?php echo e(asset('/css/guest/plugins/jquery.fancybox.css?v=1543')); ?>' rel='stylesheet' type='text/css'  media='all'  />
    <link href="<?php echo e(asset('/css/admin/plugins/quill.snow.css')); ?>" rel="stylesheet">
    <style>
        .pdHomeBlock .block-menu-right{
            background: #fff;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('template','product'); ?>

<?php $__env->startSection('head.init_js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.js'); ?>
    
    <script src='<?php echo e(asset('js/guest/plugins/jquery.fancybox.js?v=1543')); ?>' type='text/javascript'></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    <section id="insProductPage" class="tamplateSection">
        
        
        <?php echo e(Breadcrumbs::render('guest.product_detail', $product)); ?>


        <div class="container">
            <div class="wrapperPdPage">
                <div class="row">
                    <div class="col-md-9 col-sm-12 col-xs-12" id="pdWrapDetail">
                        <div class="pdBlockDetail pdFirstInfo">
                            <div class="row">
                                <div class="col-lg-7 col-md-6 col-sm-12 col-xs-12 pdImages">
                                    <div class="wrapperPdImage clearfix">
                                        <div id="leftThumbsImg" class="pdImgThumbs pull-left">
                                            <ul class="listThumbs notStyle">
                                                <li class="imgThumb">
                                                    <a href="javascript:void(0)" data-fancybox="<?php echo e(asset(Constant::$PATH_URL_UPLOAD_IMAGE.$product->product_image)); ?>" data-image="<?php echo e(asset(Constant::$PATH_URL_UPLOAD_IMAGE.$product->product_image)); ?>">
                                                        <img alt="<?php echo e($product->product_name); ?>" src="<?php echo e(asset(Constant::$PATH_URL_UPLOAD_IMAGE.$product->product_image)); ?>" >
                                                    </a>
                                                </li>
                                                <?php if(isset($product->images)): ?>
                                                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li class="imgThumb">
                                                            <a href="javascript:void(0)" data-fancybox="<?php echo e(asset(Constant::$PATH_URL_UPLOAD_IMAGE.$image->image_src)); ?>" data-image="<?php echo e(asset(Constant::$PATH_URL_UPLOAD_IMAGE.$image->image_src)); ?>">
                                                                <img alt="<?php echo e($product->product_name); ?>" src="<?php echo e(asset(Constant::$PATH_URL_UPLOAD_IMAGE.$image->image_src)); ?>" >
                                                            </a>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                            </ul>
                                        </div>
                                        <div id="imgFeatured" class="featureImg pull-left">
                                            <a class="pdFancybox" href="<?php echo e(asset(Constant::$PATH_URL_UPLOAD_IMAGE.$product->product_image)); ?>">
                                                <img alt="<?php echo e($product->product_name); ?>" src="<?php echo e(asset(Constant::$PATH_URL_UPLOAD_IMAGE.$product->product_image)); ?>" >
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-5 col-md-6 col-sm-12 col-xs-12 pdInfo">
                                    <div class="wrapPdInfo">
                                        <h1 class="title pdTitle">
                                            <?php echo e($product->product_name); ?>

                                        </h1>
                                        <div class="pdBox listInfoDesc">
                                            <ul>
                                                <li class="vendor"><i class="fa fa-gg" aria-hidden="true"></i> Thương hiệu: <span><?php echo e($product->vendor_name); ?></span> </li>
                                                <li class="type"><i class="fa fa-tags" aria-hidden="true"></i> Loại: <span><?php echo e($product->product_type_name); ?></span> </li>
                                                <li class="sku"><i class="fa fa-codepen" aria-hidden="true"></i> SKU: <span><?php echo e($product->product_code); ?></span> </li>
                                            </ul>
                                        </div>
                                        <div class="pdBox pdPriceBoxInfo">
                                            <div class="row">
                                                <div class="col-sm-12 col-xs-12 pdBlockInfo pdPriceWrap">
                                                    <div class="wrapBlockInfo">

                                                        <div class="pdPrice">
                                                            <p class="item price">
                                                                <span class="pdLabelPrice">Giá bán: </span>
                                                                <span id="pdPriceNumber">
                                                                    <?php if($product->product_price != 0): ?>
                                                                        <?php echo e(AppCommon::formatMoney($product->product_price)); ?>₫
                                                                    <?php else: ?>
                                                                        Liên hệ để biết giá
                                                                    <?php endif; ?>

                                                                </span>
                                                            </p>
                                                            <?php if(isset($product->product_cost_price) && $product->product_cost_price!= 0): ?>
                                                                <p class="item comparePrice ">
                                                                    <span class="pdLabelPrice">Giá thị trường: </span>
                                                                    <span id="pdComparePriceNumber"><?php echo e(AppCommon::formatMoney($product->product_cost_price)); ?>₫</span>
                                                                </p>
                                                                <p class="item compareSaleOff ">
                                                                    <span class="pdLabelPrice">Tiết kiệm: </span>
                                                                    <span id="pdCompareSalePrice"><?php echo e(AppCommon::formatMoney($product->product_compare_price)); ?>₫ </span>
                                                                    <?php if(isset($product->sale_percent) && $product->sale_percent > 0): ?>
                                                                        <span id="pdCompareSaleOff">-<?php echo e($product->sale_percent); ?>%</span>
                                                                    <?php endif; ?>
                                                                </p>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="shortDesc">
                                                            <div class="desc">
                                                                <?php echo e(\App\Common\AppCommon::showTextDot($product->product_description,200)); ?>

                                                            </div>

                                                        </div>
                                                        <div class="actionCart">
                                                            <div class="select clearfix" style="display:none">
                                                                <select id="product-select" name="id">

                                                                    <option value="<?php echo e($product->id); ?>">Trắng / M - 339,000₫</option>

                                                                    <option value="<?php echo e($product->id); ?>">Đen / M - 339,000₫</option>

                                                                    <option value="<?php echo e($product->id); ?>">Xanh / M - 339,000₫</option>

                                                                    <option value="<?php echo e($product->id); ?>">Trắng / L - 339,000₫</option>

                                                                    <option value="<?php echo e($product->id); ?>">Trắng / XL - 339,000₫</option>

                                                                </select>
                                                            </div>
                                                            <div class="groupQty">
                                                                <button type="button" class="qtyControl minus">-</button>
                                                                <input type="number" maxlength="12" min="1" class="input-text qty" title="Số lượng" size="2" value="1" name="Lines" id="pdQuantity">
                                                                <button type="button" class="qtyControl plus">+</button>
                                                            </div>
                                                            <div class="listAction">
                                                                <button type="button" class="button btn-outline btn-addCart">
                                                                    <span>Thêm vào giỏ</span>
                                                                </button>
                                                                
                                                                    
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="pdSocaial">
                                                            <h4>
                                                                Chia sẻ ngay
                                                            </h4>
                                                            <div class="box_social">
                                                                <div class="fb">
                                                                    <div class="fb-like" data-href="<?php echo e(route('product_detail',['slug' => $product->slug, 'id' => $product->id])); ?>" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
                                                                </div>
                                                                
                                                                    
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="pdBlockDetail pdTabInfo">
                            <div class="listTabs">
                                <ul class="nav nav-tabs" role="tablist">
                                    <li role="presentation" class="active">
                                        <a href="#tabDescription" aria-controls="tabDescription" role="tab" data-toggle="tab">Chi tiết sản phẩm</a>
                                    </li>
                                    <li role="presentation">
                                        <a href="#tabFbComment" aria-controls="tabFbComment" role="tab" data-toggle="tab">Bình luận</a>
                                    </li>
                                </ul>
                                <div class="tab-content">
                                    <div role="tabpanel" class="tab-pane fade in active" id="tabDescription">
                                        <div class="content ql-editor">
                                            <?php echo $product->product_content; ?>

                                        </div>

                                    </div>
                                    <div role="tabpanel" class="tab-pane fade" id="tabFbComment">
                                        <div class="container-comments">
                                            <div id="fb-root"></div>
                                            <div class="fb-comments" data-href="<?php echo e(route('product_detail',['slug' => $product->slug, 'id' => $product->id])); ?>" data-numposts="5" width="100%" data-colorscheme="light"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>

                        <div class="pdBlockDetail pdRelatedInfo">
                            <div class="relatedPD">
                                <div class="pdRelated">
                                    <div class="blockTitle">
                                        <h2>
                                            Có thể bạn quan tâm
                                        </h2>
                                    </div>
                                    <div class="relatedListting">
                                        <div class="contentRelatedPd pdListItem row">
                                            <?php $__currentLoopData = $productSameTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productSameType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo $__env->make('guest.common.__product_show_item_detail',['product' => $productSameType], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 hidden-sm hidden-xs" id="left_column">
                        <div class="box_sidebar">
                            
                            <?php echo $__env->make('guest.common.__right_linklist_menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            
                            <?php echo $__env->make('guest.common.__right_product_hot', ['productHots' => $productHots], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            
                            <div class="block left-module product">
                                <p class="title_block">Tags</p>
                            </div>
                            <div class="sing_right_widget pdHomeBlock" style="padding: 0px">
                                <?php echo $__env->make('guest.common.__tag_key_one', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>