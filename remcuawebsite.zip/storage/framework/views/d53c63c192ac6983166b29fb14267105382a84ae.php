<?php use App\Common\Constant; ?>

<div class="banner-slider">
    <div class="blogsList">
        <ul class="bannerSlider owlDesign notDots notStyle">
            <?php if(isset($banners)): ?>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="articleItem">
                        <a href="/collections/thoi-trang-nu">
                            <img src="<?php echo e(asset(Constant::$PATH_URL_UPLOAD_IMAGE.$banner->src_image)); ?>" alt="slider"></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>

    </div>
</div>