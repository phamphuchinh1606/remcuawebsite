<div class="nav-top visible-lg visible-md">
    <div class="container">
        <ul>
            <li><i class="fa fa-map-marker" aria-hidden="true"></i> {{$appInfo->app_address}}</li>
            <li><i class="fa fa-envelope" aria-hidden="true"></i> {{$appInfo->app_email}}</li>
            <li><i class="fa fa-mobile" aria-hidden="true"></i> {{$appInfo->app_phone}}</li>
        </ul>
    </div>
</div>