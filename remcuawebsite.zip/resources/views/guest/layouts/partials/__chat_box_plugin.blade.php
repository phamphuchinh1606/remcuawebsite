<div style="position:fixed;z-index:9999;bottom:0px;left:0;width:100%;height:42px;background:url('https://theme.hstatic.net/1000244873/1000313408/14/background-snow.png?v=1543') repeat-x bottom left;">

</div>
<canvas class="snow-canvas" speed="1" interaction="false" size="2" count="80" opacity="0.00001"
        start-color="rgba(253,252,251,1)" end-color="rgba(251,252,253,0.3)" wind-power="0" image="false" width="1366"
        height="667">

</canvas>
<canvas class="snow-canvas" speed="3" interaction="true" size="6" count="30" start-color="rgba(253,252,251,1)"
        end-color="rgba(251,252,253,0.3)" opacity="0.00001" wind-power="2" image="false" width="1366"
        height="667">

</canvas>
<canvas class="snow-canvas" speed="3" interaction="true" size="12" count="20" wind-power="-5"
        image="https://theme.hstatic.net/1000244873/1000313408/14/snow-style.png?v=1543" width="1366"
        height="667">

</canvas>
<script>
    $(".snow-canvas").snow();
</script>


<div id="fb-root"></div>
<script>(function (d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s);
        js.id = id;
        js.src = "//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.8";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>

<script>
    window.fbAsyncInit = function(){
        FB.init({
            appId : '2127242367596594',
            autoLogAppEvents : true,
            xfbml : true,
            version : 'v2.11'
        });
    };
    (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) {
            return;
        }
        js = d.createElement(s);
        js.id = id;
        js.src = "https://connect.facebook.net/vi_VN/sdk.js";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
</script>
<div class="fb-customerchat" page_id="2170410936537565"></div>

<!-- Subiz -->
<script>
    (function(s, u, b, i, z){
        u[i]=u[i]||function(){
            u[i].t=+new Date();
            (u[i].q=u[i].q||[]).push(arguments);
        };
        z=s.createElement('script');
        var zz=s.getElementsByTagName('script')[0];
        z.async=1; z.src=b; z.id='subiz-script';
        zz.parentNode.insertBefore(z,zz);
    })(document, window, 'https://widgetv4.subiz.com/static/js/app.js', 'subiz');
    subiz('setAccount', 'acqcuzewcfzahisbagsh');
</script>
<!-- End Subiz -->
