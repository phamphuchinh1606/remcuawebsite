<section id="stBrands">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <ul class="s-brand owlDesign notDots owl-carousel notStyle">


                    <li><a href="#1"><img
                                    src="https://theme.hstatic.net/1000244873/1000313408/14/home_brand_logo_1.png?v=1543"
                                    alt=""></a></li>


                    <li><a href="#2"><img
                                    src="https://theme.hstatic.net/1000244873/1000313408/14/home_brand_logo_2.png?v=1543"
                                    alt=""></a></li>


                    <li><a href="#3"><img
                                    src="https://theme.hstatic.net/1000244873/1000313408/14/home_brand_logo_3.png?v=1543"
                                    alt=""></a></li>


                    <li><a href="#4"><img
                                    src="https://theme.hstatic.net/1000244873/1000313408/14/home_brand_logo_4.png?v=1543"
                                    alt=""></a></li>


                    <li><a href="#5"><img
                                    src="https://theme.hstatic.net/1000244873/1000313408/14/home_brand_logo_5.png?v=1543"
                                    alt=""></a></li>


                    <li><a href="#6"><img
                                    src="https://theme.hstatic.net/1000244873/1000313408/14/home_brand_logo_6.png?v=1543"
                                    alt=""></a></li>


                    <li><a href="#7"><img
                                    src="https://theme.hstatic.net/1000244873/1000313408/14/home_brand_logo_7.png?v=1543"
                                    alt=""></a></li>


                    <li><a href="#8"><img
                                    src="https://theme.hstatic.net/1000244873/1000313408/14/home_brand_logo_8.png?v=1543"
                                    alt=""></a></li>


                </ul>
            </div>
        </div>
    </div>
</section>
