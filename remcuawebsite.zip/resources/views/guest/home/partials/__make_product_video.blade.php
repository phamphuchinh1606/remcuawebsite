<section id="make-product-video" class="">
    <div class="container">
        <div class="block-group-banner">
            <div class="heading-product">
						<span class="holder_header">
							<span class="line_title"></span>
						</span>
                <h4>Quy Trình Sản Xuất Rèm Màng Cửa</h4>
                <span class="holder_header">
							<span class="line_title"></span>
						</span>
            </div>
            <div class="row video">
                <div class="col-xs-12 col-sm-6 ">
                    <div class="item banner-boder-zoom2">
                        <div class="wpb_video_wrapper">
                            <iframe width="1200" height="500" src="{{$appInfo->app_make_product_video_one}}" frameborder="0" allowfullscreen=""></iframe>
                        </div>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-6 ">
                    <div class="item banner-boder-zoom2">
                        <div class="wpb_video_wrapper">
                            <iframe width="1200" height="500" src="{{$appInfo->app_make_product_video_two}}" frameborder="0" allowfullscreen=""></iframe>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>
</section>
