<?php

namespace App\Logics;

class BaseLogic{

}