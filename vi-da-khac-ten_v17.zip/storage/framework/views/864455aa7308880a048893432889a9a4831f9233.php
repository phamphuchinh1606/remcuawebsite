<div class="nav-top visible-lg visible-md">
    <div class="container">
        <ul>
            <li><i class="fa fa-map-marker" aria-hidden="true"></i> 60/30 Đồng Đen ,phường 14 ,Quận Tân Bình , Tp Hcm</li>
            <li><i class="fa fa-envelope" aria-hidden="true"></i> vidabokhactensaigon</li>
            <li><i class="fa fa-mobile" aria-hidden="true"></i> 0932 373 807</li>
        </ul>
    </div>
</div>