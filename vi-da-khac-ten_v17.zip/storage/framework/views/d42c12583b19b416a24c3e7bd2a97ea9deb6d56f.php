<?php $__env->startSection('head.css'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('body.js'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    <div class="container-fluid">
        <div id="ui-view">
            <div>
                <div class="animated fadeIn">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <strong>Cập Nhật Danh Mục</strong>
                                    <div class="card-header-actions">
                                        <a class="btn btn-sm btn-secondary" href="<?php echo e(route('admin.product_type.index')); ?>">
                                            Quay Lại
                                        </a>
                                    </div>
                                </div>
                                <form class="form-horizontal" action="<?php echo e(route('admin.product_type.update',['id' => $productType->id])); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="card-body">
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-label" for="text-input">Tên Danh Mục </label>
                                            <div class="col-md-10">
                                                <input class="form-control" id="text-input" type="text" name="product_type_name" required
                                                    value="<?php echo e($productType->product_type_name); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-lable" for="">Công Khai</label>
                                            <div class="col-md-10">
                                                <label class="switch switch-label switch-outline-primary-alt">
                                                    <input class="switch-input" type="checkbox" <?php echo e($productType->is_check_public); ?> name="is_public">
                                                    <span class="switch-slider" data-checked="On" data-unchecked="Off"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer text-right">
                                        <button class="btn btn-sm btn-primary" type="submit">
                                            <i class="fa fa-dot-circle-o"></i>Cập Nhật</button>
                                        <button class="btn btn-sm btn-danger" type="reset">
                                            <i class="fa fa-ban"></i>&nbspHủy&nbsp</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <form class="form-horizontal" action="<?php echo e(route('admin.product_type.create_children',['id' => $productType->id])); ?>" method="post" enctype="multipart/form-data">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Tạo Danh Mục Con</strong>
                                        <div class="card-header-actions">
                                            <button class="btn btn-sm btn-primary" type="submit">
                                                Thêm
                                            </button>
                                        </div>
                                    </div>
                                    <?php echo csrf_field(); ?>
                                    <div class="card-body">
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-label" for="text-input">Tên Danh Mục </label>
                                            <div class="col-md-10">
                                                <input class="form-control" id="text-input" type="text" name="product_type_name" required>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-lable" for="">Công Khai</label>
                                            <div class="col-md-10">
                                                <label class="switch switch-label switch-outline-primary-alt">
                                                    <input class="switch-input" type="checkbox" checked name="is_public">
                                                    <span class="switch-slider" data-checked="On" data-unchecked="Off"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-header">
                                        <strong>Danh Sách Danh Mục Con</strong>
                                    </div>
                                    <div class="card-body">
                                        <table class="table table-responsive-sm table-bordered">
                                            <thead>
                                            <tr>
                                                <th>Tên Danh Mục</th>
                                                <th>Tình Trạng</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $listChildren; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productTypeChild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($productTypeChild->product_type_name); ?></td>
                                                        <td>
                                                            <span class="badge <?php echo e($productTypeChild->public_class); ?>"><?php echo e($productTypeChild->public_name); ?></span>
                                                        </td>
                                                        <td>
                                                            <a data-toggle="modal" class="btn btn-danger anchorClick"
                                                                data-url="<?php echo e(route('admin.product_type.delete_children',['id' => $productType->id, 'childId' => $productTypeChild->id])); ?>"
                                                                data-name="<?php echo e($productTypeChild->product_type_name); ?>" href="#deleteModal">
                                                                <i class="fa fa-trash-o"></i>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>