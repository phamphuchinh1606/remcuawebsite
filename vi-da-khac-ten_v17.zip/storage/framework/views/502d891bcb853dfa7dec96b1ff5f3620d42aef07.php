<?php $__env->startSection('head.title','Danh Sách Sản Phẩm'); ?>

<?php $__env->startSection('head.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body.content'); ?>
    <div class="container-fluid">
        <div id="ui-view">
            <div>
                <div class="animated fadeIn">
                    <div class="card">
                        <div class="card-header">
                            <i class="fa fa-edit"></i> Danh Sách Sản Phẩm
                            <div class="card-header-actions">
                                <a class="btn btn-block btn-outline-primary active" href="<?php echo e(route('admin.product.create')); ?>">
                                    Tạo mới
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <table class="table table-striped table-bordered datatable dataTable no-footer" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info" style="border-collapse: collapse !important">
                                            <thead>
                                            <tr role="row">
                                                <th class="sorting_asc">
                                                    Số Thứ Tự
                                                </th>
                                                <th class="sorting" >
                                                    Hình Ảnh
                                                </th>
                                                <th class="sorting" >
                                                    Tên Sản Phẩm
                                                </th>
                                                <th class="sorting" >
                                                    Mã Sản Phẩm
                                                </th>
                                                <th class="sorting" >
                                                    Loại Sản Phẩm
                                                </th>
                                                <th class="sorting" >
                                                    Giá Bán
                                                </th>
                                                <th class="sorting" >
                                                    Tình Trạng
                                                </th>
                                                <th class="sorting">
                                                    Actions
                                                </th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            
                                                
                                                    
                                                        
                                                    
                                                    
                                                        
                                                    
                                                    
                                                        
                                                    
                                                    
                                                        
                                                            
                                                        
                                                        
                                                            
                                                        
                                                        
                                                            
                                                        
                                                    
                                                
                                            
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>