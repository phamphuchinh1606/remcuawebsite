<?php use App\Common\Constant; ?>
<div class="sing_right_widg_content">
    <ul class="lat_news_right">
        <?php if(isset($blogNews)): ?>
            <?php $__currentLoopData = $blogNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="newItem">
                    <div class="wrap clearfix">
                        <a href="<?php echo e(route('blog.detail',['id' => $blog->id])); ?>">
                            <img src="<?php echo e(asset(Constant::$PATH_URL_UPLOAD_IMAGE.$blog->blog_image)); ?>" alt="<?php echo e($blog->blog_title); ?>">
                        </a>
                        <div class="lat_news_right_con">
                            <h3>
                                <a href="<?php echo e(route('blog.detail',['id' => $blog->id])); ?>"><?php echo e($blog->dot_blog_title); ?></a>
                            </h3>
                            <h4><?php echo e($blog->str_post_date); ?></h4>
                        </div>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ul>
</div>