<?php use App\Common\AppCommon; ?>
<div class="sidebar-content">
    <div class="order-summary order-summary-is-collapsed">
        <h2 class="visually-hidden">Thông tin đơn hàng</h2>
        <div class="order-summary-sections">
            <div class="order-summary-section order-summary-section-product-list" data-order-summary-section="line-items">
                <table class="product-table">
                    <thead>
                    <tr>
                        <th scope="col"><span class="visually-hidden">Hình ảnh</span></th>
                        <th scope="col"><span class="visually-hidden">Mô tả</span></th>
                        <th scope="col"><span class="visually-hidden">Số lượng</span></th>
                        <th scope="col"><span class="visually-hidden">Giá</span></th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $carts =  Cart::getContent()?>
                        <?php if(isset($carts)): ?>
                            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $image = $cart->attributes->has('image') ? $cart->attributes['image'] : ''; ?>
                                <tr class="product" data-product-id="<?php echo e($cart->id); ?>" data-variant-id="<?php echo e($cart->id); ?>">
                                    <td class="product-image">
                                        <div class="product-thumbnail">
                                            <div class="product-thumbnail-wrapper">
                                                <img class="product-thumbnail-image" alt="<?php echo e($cart->name); ?>" src="<?php echo e($image); ?>" />
                                            </div>
                                            <span class="product-thumbnail-quantity" aria-hidden="true"><?php echo e($cart->quantity); ?></span>
                                        </div>
                                    </td>
                                    <td class="product-description">
                                        <span class="product-description-name order-summary-emphasis"><?php echo e($cart->name); ?></span>
                                    </td>
                                    <td class="product-quantity visually-hidden"><?php echo e($cart->quantity); ?></td>
                                    <td class="product-price">
                                        <span class="order-summary-emphasis"><?php echo e(AppCommon::formatMoney($cart->getPriceSum())); ?>₫</span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
                
                    
                    
                        
                            
                                
                                    
                                    
                                
                                
                                    
                                    
                                
                            

                        
                    
                
            

            <div class="order-summary-section order-summary-section-total-lines" data-order-summary-section="payment-lines">
                <table class="total-line-table">
                    <thead>
                    <tr>
                        <th scope="col"><span class="visually-hidden">Mô tả</span></th>
                        <th scope="col"><span class="visually-hidden">Giá</span></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr class="total-line total-line-subtotal">
                        <td class="total-line-name">Tạm tính</td>
                        <td class="total-line-price">
                            <span class="order-summary-emphasis" data-checkout-subtotal-price-target="<?php echo e(Cart::getSubTotal()); ?>">
                                <?php echo e(AppCommon::formatMoney(Cart::getSubTotal())); ?>₫
                            </span>
                        </td>
                    </tr>
                    <tr class="total-line total-line-shipping">
                        <td class="total-line-name">Phí vận chuyển</td>
                        <td class="total-line-price">
                            <span class="order-summary-emphasis" data-checkout-total-shipping-target="0">
                                —
                            </span>
                        </td>
                    </tr>
                    </tbody>
                    <tfoot class="total-line-table-footer">
                    <tr class="total-line">
                        <td class="total-line-name payment-due-label">
                            <span class="payment-due-label-total">Tổng cộng</span>
                        </td>
                        <td class="total-line-name payment-due">
                            <span class="payment-due-currency">VND</span>
                            <span class="payment-due-price" data-checkout-payment-due-target="<?php echo e(Cart::getTotal()); ?>">
                                <?php echo e(AppCommon::formatMoney(Cart::getTotal())); ?>₫
                            </span>
                        </td>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>