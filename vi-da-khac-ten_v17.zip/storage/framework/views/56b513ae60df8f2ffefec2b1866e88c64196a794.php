<?php use App\Common\Constant; ?>
<section id="banner-home-top" class="">
    <div class="container">
        <div class="block-group-banner">
            <?php if(isset($topBanners)): ?>
                <?php $__currentLoopData = $topBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-12 col-sm-4 padding-0 item banner-boder-zoom2 first">
                        <a href="#" class="">
                            <img src="<?php echo e(asset(Constant::$PATH_URL_UPLOAD_IMAGE.$banner->src_image)); ?>"
                                 alt="alt"/>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</section>