<div class="block left-module linklist">
    <p class="title_block">Danh mục sản phẩm</p>
    <div class="block_content">
        <!-- layered -->
        <div class="layered layered-category">
            <div class="layered-content">
                <ul class="tree-menu notStyle">
                    <?php $__currentLoopData = $productTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="">
                            <span></span>
                            <a class="" href="<?php echo e(route('collection',['id' => $productType->id])); ?>" title="Đồng hồ" target="_self">
                                <?php echo e($productType->product_type_name); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <!-- ./layered -->
    </div>
</div>