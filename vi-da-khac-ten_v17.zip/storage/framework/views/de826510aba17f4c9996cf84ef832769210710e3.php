
    
        
            
                
                
                
                    
                    
                    
                
            
        
    



    
        
            
                
                    
                
                
                
            
            
                
            
            
                
                
                    
                    
                    
                

            
        
    

<div id="deleteModal" class="modal fade">
    <div class="modal-dialog modal-danger" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Xác nhận xóa</h4>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Bạn có thực sự muốn xóa : "<span id="confirm-delete-name"></span>" ?</p>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Hủy</button>
                <form class="inline" action="route_delete" method="post" id="formHolder">
                    <?php echo csrf_field(); ?>
                    <input name="_method" type="hidden" value="DELETE">
                    <button class="btn btn-danger" type="submit">Xóa</button>
                </form>

            </div>
        </div>

    </div>

</div>

<script>
    function dataDeletePopup() {
        $('.anchorClick').each(function () {
            $(this).on('click', function () {
                var $url = $(this).attr('data-url');
                var $name = $(this).attr('data-name');
                $('#formHolder').attr('action', $url);
                $('#confirm-delete-name').html($name);
            });
        });

    }
    $(document).ready(function () {
        dataDeletePopup();
    })
</script>
