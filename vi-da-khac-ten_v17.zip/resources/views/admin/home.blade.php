@extends('admin.layouts.master')

@section('body.content')
    Trang chu
@endsection
