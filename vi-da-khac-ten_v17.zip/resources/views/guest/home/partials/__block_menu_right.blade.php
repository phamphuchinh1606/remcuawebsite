<div class="block-menu-right">
    <ul class="list notStyle clearfix">

        <li><a href="/">Giày thể thao</a></li>

        <li><a href="/">Giày chạy bộ</a></li>

        <li><a href="/">Giày tập golf</a></li>

        <li><a href="/">Giày đá bóng</a></li>

        <li><a href="/">Giày chơi bóng rổ</a></li>

        <li><a href="/">Giày chơi cầu lông</a></li>

        <li><a href="/">Giày đá bóng</a></li>

        <li><a href="/">Giày thể thao</a></li>

        <li><a href="/">Giày đạp xe</a></li>

        <li><a href="/">Giày leo núi</a></li>

        <li><a href="/">Giày trượt ván nữ</a></li>

        <li><a href="/">Giày tập thể hình</a></li>

        <li><a href="/">Giày cao gót</a></li>

        <li><a href="/">Giày lười</a></li>

        <li><a href="/">Giày Sneaker</a></li>

        <li><a href="/">Giày Converse</a></li>

    </ul>
</div>