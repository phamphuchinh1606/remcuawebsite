<div class="itemProduct col-md-3 col-sm-6 col-xs-6 ">
    <div class="pdLoopItem animated zoomIn">
        <div class="itemLoop clearfix">
            <div class="pdLoopImg elementFixHeight">
                <div class="pdLabel sale">
                    <span>- 17%</span>
                </div>
                <a href="/products/ao-hoodie-nu-chu-theu-thoi-trang-sid53235" title="Áo hoodie nữ chữ thêu thời trang SID53235">
                    <img alt="Áo hoodie nữ chữ thêu thời trang SID53235" data-reg="true" class="imgLoopItem" src="{{asset('./images/guest/product_detail/product_same_type_1.jpg')}}" style="width: auto;">
                </a>
                <div class="pdLoopAction hidden-sm hidden-xs">
                    <div class="listAction">
                        <a href="javascript:void(0)" class="add-cart btnLoop Addcart" data-variantid="1019674046" title="Thêm vào giỏ"><i class="fa fa-shopping-bag" aria-hidden="true"></i> <span>Thêm vào giỏ</span></a>
                        <a href="javascript:void(0)" class="btnLoop btnQickview btn-quickview-1" data-handle="{{route('product.quick_view',['id' => 1])}}" data-toggle="tooltip" data-placement="left" title="Xem nhanh"><i class="fa fa-search-plus" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
            <div class="pdLoopDetail text-center clearfix">
                <h3 class="pdLoopName"><a class="productName" href="/products/ao-hoodie-nu-chu-theu-thoi-trang-sid53235" title="Áo hoodie nữ chữ thêu thời trang SID53235">Ví da cao cấp 01</a></h3>
                <p class="pdPrice">

                    <span>380,000₫</span>
                    <del class="pdComparePrice">460,000₫</del>

                </p>
                <div class="pdLoopListView">
                    <ul class="notStyle">
                        <li><strong>Mã sản phẩm: </strong><span>chưa rõ</span></li>
                        <li><strong>Thương hiệu: </strong><span>H&amp;M</span></li>
                        <li><strong>Mô tả ngắn: </strong>
                            <span class="short-des">
							    Áo hoodie nữ chữ thêu thời trang có thiết kế thời trang phối nón vô cùng tinh tế giúp bạn gái tự tin và trẻ trung hơn trong mọi hoạt động hằng ngàyDáng áo vừa vặn, phần thân và tay có bo gấu và phối màu trẻ trung vô cùng thu hútPhần cổ có dây cột điệu đà, trước ngực có họa tiết chữ độc đáo và năng độngMàu sắc đa dạng để bạn có thể thoải mái lựa chọn theo sở thích cũng như phối với style riêng của mìnhChất liệu thun mềm mại, thoáng mát, thấm hút mồ hôi...
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>