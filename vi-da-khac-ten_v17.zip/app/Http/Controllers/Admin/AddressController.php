<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Curl;

class AddressController extends Controller
{
    protected $countryUrl = 'https://ezcmd.com/apps/ajax_apps/get_countries?term=';
    protected $provinceUrl = 'https://ezcmd.com/apps/ajax_apps/get_sd1/VN?term=';
    protected $districtUrl = 'https://ezcmd.com/apps/ajax_apps/get_sd2/VN/1594446?term=';

    public function init(){
        //Url get country
        $response = Curl::to($this->countryUrl)->get();
        $countries = json_decode($response);
        foreach ($countries as $country){
            $countryCode = $country->country_code;
            $countryName = $country->country_name;
            $label = $country->label;
            $value = $country->value;
        }
        dd('vao');
    }
}
