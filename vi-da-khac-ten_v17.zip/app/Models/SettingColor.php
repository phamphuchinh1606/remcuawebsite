<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SettingColor extends Model
{
    protected $table = 'setting_color';
}
