$('.datatable').DataTable();
$('.datatable').attr('style','border-collapse: collapse !important');